package com.example.cr1.rat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  {

    private String TAG="Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(getBaseContext(),"create",Toast.LENGTH_LONG).show();
        Log.w(TAG,"create");
        Button send =findViewById(R.id.button);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"data stored",Toast.LENGTH_LONG).show();
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getBaseContext(),"Start",Toast.LENGTH_LONG).show();
        Log.w(TAG,"start");
    }



    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getBaseContext(),"Resume",Toast.LENGTH_LONG).show();
        Log.w(TAG,"resume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getBaseContext(),"Pause",Toast.LENGTH_LONG).show();
        Log.w(TAG,"pause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(getBaseContext(),"Stop",Toast.LENGTH_LONG).show();
        Log.w(TAG,"stop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(getBaseContext(),"Restart",Toast.LENGTH_LONG).show();
        Log.w(TAG,"restart");

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(getBaseContext(),"Destroy",Toast.LENGTH_LONG).show();
        Log.w(TAG,"destory");
    }

}
